======================================================
  HIVAX — Como gerar o hivax.exe
  Dono: https://github.com/0xKxbyte
======================================================

PRE-REQUISITOS
--------------
  Python 3.10+ instalado no Windows
  pip install PyQt6 pyinstaller

ARQUIVOS NECESSARIOS (na mesma pasta)
--------------------------------------
  hivax.py
  hivax.spec
  version_info.txt
  Cronometro.ico
  Cronometro.png
  Alarme1S.mp3
  build_windows.bat

GERAR O .EXE
------------
  Metodo 1 — Abra o build_windows.bat (duplo clique)
  Metodo 2 — No terminal da pasta:
      pyinstaller --clean hivax.spec

RESULTADO
---------
  dist\hivax.exe   <- executavel final (tudo embutido)

NOTAS DO EXE
------------
  Dono:        https://github.com/0xKxbyte
  Produto:     Hivax - Cronometro & Alarme
  Versao:      1.0.0
  Icone:       Cronometro.ico
  Musica pad.: Alarme1S.mp3 (embutida)
======================================================
