@echo off
REM ============================================================
REM  Hivax — Build Script para Windows
REM  Dono: https://github.com/0xKxbyte
REM ============================================================
echo Instalando dependencias...
pip install PyQt6 pyinstaller

echo.
echo Gerando hivax.exe ...
pyinstaller --clean hivax.spec

echo.
echo Pronto! O executavel esta em: dist\hivax.exe
pause
